package com.example.hackathon;

import com.example.hackathon.model.DummyUser;
import com.example.hackathon.model.Lecture;
import com.example.hackathon.repo.DummyUserRepo;
import com.example.hackathon.repo.LectureRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackathonApplication implements CommandLineRunner {

    @Autowired
    private DummyUserRepo dummyUserRepo;

    @Autowired
    private LectureRepo lectureRepo;

    public static void main(String[] args) {
        SpringApplication.run(HackathonApplication.class, args);
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        DummyUser dummyUser = new DummyUser();
        dummyUser.setUsername("sadGato_123");
        dummyUser.setCourseName("Mathematics");
        dummyUser.setUniversityName("Imperial College London");
        dummyUser.setInitialInvestment(30000.00);
        dummyUser.setMoneyLost(700.00);

        dummyUserRepo.save(dummyUser);

        Lecture lecture = new Lecture();
        lecture.setTotalCourse(600);
        lecture.setMissedCourse(14);
        lecture.setLecturePercentage("97%");

        lectureRepo.save(lecture);

    }
}
