package com.example.hackathon.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Lecture {
    @Id
    private int id;
    private String lecturePercentage;
    private int totalCourse;
    private int missedCourse;

    public String getLecturePercentage() {
        return lecturePercentage;
    }

    public void setLecturePercentage(String lecturePercentage) {
        this.lecturePercentage = lecturePercentage;
    }

    public int getTotalCourse() {
        return totalCourse;
    }

    public void setTotalCourse(int totalCourse) {
        this.totalCourse = totalCourse;
    }

    public int getMissedCourse() {
        return missedCourse;
    }

    public void setMissedCourse(int missedCourse) {
        this.missedCourse = missedCourse;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



}
