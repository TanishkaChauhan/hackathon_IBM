package com.example.hackathon.repo;

import com.example.hackathon.model.DummyUser;
import org.springframework.data.repository.CrudRepository;

public interface DummyUserRepo extends CrudRepository<DummyUser, Integer> {

}
