package com.example.hackathon.controller;


import com.example.hackathon.model.DummyUser;
import com.example.hackathon.model.Lecture;
import com.example.hackathon.repo.DummyUserRepo;
import com.example.hackathon.repo.LectureRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller

public class TrackerController {
    @Autowired
    private DummyUserRepo dummyUserRepo;
    @Autowired
    private LectureRepo lectureRepo;

    @RequestMapping("/")
    public String landingPage(){
        return "landingPage";
    }

    @RequestMapping("/signUp")
    public String signUp(){
        return "signUp";
    }

    @RequestMapping("/loginPage")
    public String loginPage(){
        return "loginPage";
    }

    @RequestMapping("/forgotPassword")
    public String forgotPassword(){
        return "forgotPassword";
    }

    @RequestMapping("/homePage")
    public String homePage(Model model){
        Iterable<DummyUser> dummyUsers = dummyUserRepo.findAll();
        model.addAttribute("user", dummyUserRepo.findAll());
        model.addAttribute("lecture",lectureRepo.findAll());

        return "homePage";
    }

    @GetMapping("/updateAttendance")
    // to update the lecture percentage
    // ask tanim to do the maths
    
    public String updateAttendance(@RequestParam("classesAttended") int classesAttended) {
        Lecture lecture = lectureRepo.findById(1).orElse(null);
        DummyUser dummyUser = dummyUserRepo.findById(1).orElse(null);

        if (lecture != null) {
            int totalClasses = lecture.getTotalCourse();
            int missedClasses = totalClasses - classesAttended;
            lecture.setMissedCourse(missedClasses);

            double attendancePercentage = ((double) (totalClasses - missedClasses) / totalClasses) * 100;
            lecture.setLecturePercentage(String.format("%.2f", attendancePercentage));

            double costPerLecture = dummyUser.getInitialInvestment()/ lecture.getTotalCourse();
            double absent=(double) 100-attendancePercentage;
            dummyUser.setMoneyLost(absent*costPerLecture);


            lectureRepo.save(lecture);
            dummyUserRepo.save(dummyUser);
        }

        return "redirect:/homePage";
    }
}
