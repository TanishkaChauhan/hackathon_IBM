package com.example.hackathon.repo;

import com.example.hackathon.model.Lecture;
import org.springframework.data.repository.CrudRepository;

public interface LectureRepo extends CrudRepository<Lecture, Integer> {
}
